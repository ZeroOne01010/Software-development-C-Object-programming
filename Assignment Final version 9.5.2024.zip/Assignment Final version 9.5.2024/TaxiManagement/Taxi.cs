﻿using System;

namespace TaxiManagement
{
    public class Taxi
    {
        public const string ON_ROAD = "on the road";
        public const string IN_RANK = "in rank";

        public int Number { get; }
        public double CurrentFare { get; private set; }
        public string Destination { get; private set; } = "";
        public string Location { get; private set; } = ON_ROAD;
        public double TotalMoneyPaid { get; private set; }
        private Rank _rank;

        public Rank Rank
        {
            get { return _rank; }
            set
            {
                if (value == null)
                {
                    throw new Exception("Rank cannot be null");
                }

                if (!string.IsNullOrEmpty(Destination))
                {
                    throw new Exception("Cannot join rank if fare has not been dropped");
                }

                _rank = value;
                Location = IN_RANK;
            }
        }

        public object Id { get; internal set; } //Internal to be only used in this assembly but hidden from other assemblys 

        public Taxi(int taxiNum)
        {
            Number = taxiNum;
            
        }

        public void AddFare(string destination, double agreedPrice)
        {
            _rank = null;
            Location = ON_ROAD;
            Destination = destination;
            CurrentFare = agreedPrice;
        }

        public void DropFare(bool priceWasPaid)
        {
            if (priceWasPaid)
            {
                TotalMoneyPaid += CurrentFare;
            }
            CurrentFare = 0;
            Destination = "";
        }

        public void SetDestination(string destination)
        {
            Destination = destination;
        }

        public void SetFare(double fare)
        {
            CurrentFare = fare;
        }
    }
}