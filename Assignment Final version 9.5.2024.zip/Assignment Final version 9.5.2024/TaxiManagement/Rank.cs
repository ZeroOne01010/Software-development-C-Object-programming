﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;


namespace TaxiManagement
{
    public class Rank
    {
        public int Id { get; }
        public int NumberOfTaxiSpaces { get; }
        public List<Taxi> Taxis { get; }

        public Rank(int rankId, int numberOfTaxiSpaces)
        {
            Id = rankId;
            NumberOfTaxiSpaces = numberOfTaxiSpaces;
            Taxis = new List<Taxi>();
        }

        public bool AddTaxi(Taxi taxi)
        {
            if (Taxis.Count < NumberOfTaxiSpaces)
            {
                Taxis.Add(taxi);
                taxi.Rank = this;
                return true;
            }
            return false;
        }

        public Taxi FrontTaxiTakesFare(string destination, double fare)
        {
            if (Taxis.Count > 0)
            {
                Taxi frontTaxi = Taxis[0];
                frontTaxi.DropFare(true);
                frontTaxi.AddFare(destination, fare);
                Taxis.RemoveAt(0);
                return frontTaxi;
            }
            return null;
        }

        public Taxi FrontTaxiTakesFare()// issues default values in the absence of inputted values
        {
            string defaultDestination = "DefaultDestination";
            double defaultFare = 0.0;

            return FrontTaxiTakesFare(defaultDestination, defaultFare);
        }
    }
}