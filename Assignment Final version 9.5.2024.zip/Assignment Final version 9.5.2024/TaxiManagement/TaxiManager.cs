﻿using System.Collections.Generic;
using System.Linq;

namespace TaxiManagement
{
    public class TaxiManager
    {
        private SortedDictionary<int, Taxi> _taxis;

        public TaxiManager()
        {
            _taxis = new SortedDictionary<int, Taxi>();
        }

        public Taxi CreateTaxi(int taxiNum)
        {
            Taxi taxi = FindTaxi(taxiNum);
            if (taxi == null)
            {
                taxi = new Taxi(taxiNum);
                _taxis.Add(taxiNum, taxi);
            }
            return taxi;
        }

        public Taxi FindTaxi(int taxiNum)
        {
            try
            {
                return _taxis[taxiNum];
            }
            catch (KeyNotFoundException)
            {
                return null;
            }
        }

        public SortedDictionary<int, Taxi> GetAllTaxis()
        {
            return _taxis;
        }
    }
}