﻿using System;
using System.Collections.Generic;

namespace TaxiManagement
{
    public class RankManager
    {
        private Dictionary<int, Rank> _ranks;

        public RankManager()
        {
            _ranks = new Dictionary<int, Rank>();
            _ranks.Add(1, new Rank(1, 5));// ranges for taxis allowed in ranks, 1,2,3
            _ranks.Add(2, new Rank(2, 2));
            _ranks.Add(3, new Rank(3, 4));
        }

        public bool AddTaxiToRank(Taxi taxi, int rankId)
        {
            if (taxi.Location == Taxi.ON_ROAD && string.IsNullOrEmpty(taxi.Destination))
            {
                Rank rank = FindRank(rankId);
                if (rank != null)
                {
                    return rank.AddTaxi(taxi);
                }
            }
            return false;
        }

        public Rank FindRank(int rankId)
        {
            try
            {
                return _ranks[rankId];
            }
            catch (KeyNotFoundException)
            {
                return null;
            }
        }

        public Taxi FrontTaxiInRankTakesFare(int rankId, string destination, double agreedPrice)
        {
            Rank rank = FindRank(rankId);
            try
            {
                return _ranks[rankId].FrontTaxiTakesFare(destination, agreedPrice);
            }
            catch
            {
                return null;
            }
        }
    }
}