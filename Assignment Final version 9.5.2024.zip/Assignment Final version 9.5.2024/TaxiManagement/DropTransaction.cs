﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaxiManagement
{
    public class DropTransaction : Transaction //Inherited from transaction class 
    {
        private int taxiNumber;
        private bool priceWasPaid;

        public DropTransaction(DateTime transactionDatetime, int taxiNumber, bool priceWasPaid)
            : base(transactionDatetime)
        {
            this.taxiNumber = taxiNumber;
            this.priceWasPaid = priceWasPaid;
        }

        public override string TransactionType => "Drop fare"; //Overide execcutes this class rather than the base classs methods etc 

        public override string ToString() //Overide execcutes this class rather than the base classs methods etc 
        {
            string dateStr = TransactionDatetime.ToString("dd/MM/yyyy HH:mm");
            string paidStatus = priceWasPaid ? "price was paid" : "price was not paid";
            return $"{dateStr} Drop fare - Taxi {taxiNumber}, {paidStatus}";
        }
    }
}
