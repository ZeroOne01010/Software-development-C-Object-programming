﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaxiManagement
{
    public abstract class Transaction //Abstract keyword, no implementation
    {
        public DateTime TransactionDatetime { get; }
        public abstract string TransactionType { get; }

        protected Transaction(DateTime transactionDatetime)
        {
            TransactionDatetime = transactionDatetime;
        }

        public abstract override string ToString();
    }
}
