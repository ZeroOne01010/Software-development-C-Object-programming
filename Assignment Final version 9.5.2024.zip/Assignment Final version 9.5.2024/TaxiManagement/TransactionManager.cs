﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaxiManagement
{
    public class TransactionManager
    {
        public List<Transaction> Transactions { get; private set; }

        public TransactionManager()
        {
            Transactions = new List<Transaction>();
        }

        public void RecordJoin(int rankId, int taxiNumber)// Create a new JoinTransaction and add it to the collection
        {
            DateTime now = DateTime.Now;
            JoinTransaction joinTransaction = new JoinTransaction(now, taxiNumber, rankId);
            Transactions.Add(joinTransaction);
        }

        public void RecordLeave(int rankId, Taxi taxi) // Create a new LeaveTransaction and add it to the collection
        {
            DateTime now = DateTime.Now;
            LeaveTransaction leaveTransaction = new LeaveTransaction(now, rankId, taxi);
            Transactions.Add(leaveTransaction);
        }

        public void RecordDrop(int taxiNumber, bool priceWasPaid)// Create a new DropTransaction and add it to the collection
        {
            DateTime now = DateTime.Now;
            DropTransaction dropTransaction = new DropTransaction(now, taxiNumber, priceWasPaid);
            Transactions.Add(dropTransaction);
        }
    }
}
