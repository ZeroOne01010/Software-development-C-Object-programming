﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaxiManagement
{
    public class JoinTransaction : Transaction //Inheritance
    {
        private int taxiNumber;
        private int rankId;

        public JoinTransaction(DateTime transactionDatetime, int taxiNumber, int rankId)
            : base(transactionDatetime)
        {
            this.taxiNumber = taxiNumber;
            this.rankId = rankId;
        }

        public override string TransactionType => "Join"; //Overide execcutes this class rather than the base classs methods etc 

        public override string ToString() //Overide execcutes this class rather than the base classs methods etc 
        {
            string dateStr = TransactionDatetime.ToString("dd/MM/yyyy HH:mm");
            return $"{dateStr} Join      - Taxi {taxiNumber} in rank {rankId}";
        }
    }
}
