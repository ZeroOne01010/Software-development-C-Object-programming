﻿using System;
using System.Collections.Generic;

namespace TaxiManagement
{
    public class UserUI
    {
        private RankManager rankManager;
        private TaxiManager taxiManager;
        private TransactionManager transactionManager;

        public UserUI(RankManager rm, TaxiManager txm, TransactionManager trm)
        {
            rankManager = rm;
            taxiManager = txm;
            transactionManager = trm;
        }

        public List<string> TaxiJoinsRank(int taxiId, int rankId)
        {
            List<string> messages = new List<string>();
            Taxi taxi = taxiManager.FindTaxi(taxiId) ?? taxiManager.CreateTaxi(taxiId); //?? - if Null code on the reigh executes 
            bool success = rankManager.AddTaxiToRank(taxi, rankId);

            if (success)
            {
                transactionManager.RecordJoin(taxiId, rankId);
                messages.Add($"Taxi {taxiId} has joined rank {rankId}.");
            }
            else
            {
                messages.Add($"Taxi {taxiId} has not joined rank {rankId}.");
            }

            return messages;
        }

        public List<string> TaxiLeavesRank(int rankId, string destination, double fare)
        {
            List<string> messages = new List<string>();

            Taxi taxi = rankManager.FindRank(rankId)?.FrontTaxiTakesFare(destination, fare);

            if (taxi != null)
            {
                transactionManager.RecordLeave(rankId, taxi);
                messages.Add($"Taxi {taxi.Number} has left rank {rankId} to take a fare to {destination} for £{fare:F2}.");
                rankManager.FrontTaxiInRankTakesFare(rankId, destination, fare);

            }
            else
            {
                messages.Add($"Taxi has not left rank {rankId}."); 
            }


            return messages;
        }

        public List<string> TaxiDropsFare(int taxiId, bool priceWasPaid)
        {
            List<string> messages = new List<string>();
            Taxi taxi = taxiManager.FindTaxi(taxiId);

            if (priceWasPaid)
            {
                messages.Add($"Taxi {taxiId} has dropped its fare and the price was paid.");
                if (taxiManager.FindTaxi(taxiId).Rank == null)
                {
                    transactionManager.RecordDrop(taxiId, true);
                    taxi.DropFare(true);
                }

            }
            else
            {
                if (taxi.Destination == "")
                {
                    messages.Add($"Taxi {taxiId} has not dropped its fare.");
                }
                else
                {
                    messages.Add($"Taxi {taxiId} has dropped its fare and the price was not paid.");
                    transactionManager.RecordDrop(taxiId, false);

                }
            }

            return messages;

        }


        public List<string> ViewTaxiLocation()
        {
            List<string> messages = new List<string>();
            messages.Add("Taxi locations");
            messages.Add("==============");

            var allTaxis = taxiManager.GetAllTaxis();

            if (allTaxis.Count == 0)
            {
                messages.Add("No taxis");
                return messages;
            }

            foreach (var taxi in allTaxis.Values)
            {
                string locationMessage = taxi.Rank != null ?
                    $"Taxi {taxi.Id} is in rank {taxi.Rank.Id}" :
                    $"Taxi {taxi.Id} is on the road to {taxi.Destination}";
                messages.Add(locationMessage);
            }

            return messages;
        }

        public List<string> ViewFinancialReport()
        {
            List<string> messages = new List<string>();
            messages.Add("Financial report");
            messages.Add("================");

            var allTaxis = taxiManager.GetAllTaxis();
            double total = 0;

            if (allTaxis.Count == 0)
            {
                messages.Add("No taxis, so no money taken");
            }
            else
            {
                foreach (var taxi in allTaxis.Values)
                {
                    messages.Add($"Taxi {taxi.Id}      {taxi.TotalMoneyPaid:F2}");
                    total += taxi.TotalMoneyPaid;
                }
            }

            messages.Add("           ======");
            messages.Add($"Total:       {total:F2}");
            messages.Add("           ======");

            return messages;
        }


        public List<string> ViewTransactionLog()
        {
            List<string> messages = new List<string>();
            messages.Add("Transaction report");
            messages.Add("==================");

            if (transactionManager.Transactions.Count == 0)
            {
                messages.Add("No transactions");
                return messages;
            }

            foreach (var transaction in transactionManager.Transactions)
            {
                messages.Add(transaction.ToString());
            }

            return messages;
        }

        public List<string> ViewTaxiLocations()
        {
            List<string> messages = new List<string>();
            messages.Add("Taxi locations");
            messages.Add("==============");

            var allTaxis = taxiManager.GetAllTaxis();

            if (allTaxis.Count == 0)
            {
                messages.Add("No taxis");
                return messages;
            }

            foreach (var taxi in allTaxis.Values)
            {
                string locationMessage = taxi.Rank != null ?
                    $"Taxi {taxi.Id} is in rank {taxi.Rank.Id}" :
                    $"Taxi {taxi.Id} is on the road to {taxi.Destination}";
                messages.Add(locationMessage);
            }

            return messages;
        }
    }
}
