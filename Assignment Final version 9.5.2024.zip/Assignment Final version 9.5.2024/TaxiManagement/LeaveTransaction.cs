﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace TaxiManagement
{
    public class LeaveTransaction : Transaction //Inheritance
    {
        private int taxiNumber;
        private string destination;
        private double fareAmount;
        private int rankId; 

        public LeaveTransaction(DateTime transactionDatetime, int rankId, Taxi taxi)
            : base(transactionDatetime)
        {
            this.taxiNumber = taxi.Number;
            this.destination = taxi.Destination;
            this.fareAmount = taxi.CurrentFare;
            this.rankId = rankId; 
        }

        public override string TransactionType => "Leave"; //Overide execcutes this class rather than the base classs methods etc 

        public override string ToString() //Overide execcutes this class rather than the base classs methods etc 
        {
            string dateStr = TransactionDatetime.ToString("dd/MM/yyyy HH:mm");
            return $"{dateStr} Leave     - Taxi {taxiNumber} from rank {rankId} to {destination} for £{fareAmount:F2}";
        }
    }
}
